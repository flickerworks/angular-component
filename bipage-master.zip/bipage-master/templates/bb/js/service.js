chartsApp.service("dataService", function($http) {
    this.getData = function(url) {
        return $http.get(url);
    }
    this.lineChartConfig = function() {
        return lineChartOptions;
    }
    this.funnelChartConfig = function() {
        return pyramidChartOptions;
    };
    this.circularGraphObject = function() {
        return circularChartOptions;
    }
})