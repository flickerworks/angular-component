document.write('<div id="adsense" style="visibility: hidden; height: 0;">yipee! an advertisement</div>');
