chartsApp.directive('circularGraph', function() {
    return {
        restrict: "E",
        scope: {
            caption: "@",
            colorsArray: "=",
            graphDataUrl: "=",
            height: "@",
            type: "@",
            direction: "@"
        },
        template: '<div fusioncharts width="100%" height="{{height}}px" type="{{type}}" dataSource="{{options}}"></div>',
        controller: function($scope, dataService) {
            console.log($scope.caption)
            var circularChartOptions = {
                "chart": {
                    "enableSmartLabels": "1",
                    "chartTopMargin": "0",
                    "chartRightMargin": "0",
                    "chartBottomMargin": "0",
                    "caption": "",
                    "subCaption": "",
                    "numberPrefix": "",
                    "bgColor": "#ffffff",
                    "showBorder": "0",
                    "use3DLighting": "0",
                    "showShadow": "0",
                    "enableSmartLabels": "0",
                    "startingAngle": "310",
                    "showLabels": "0",
                    "showValues": "1",
                    "showPercentValues": "1",
                    "showLegend": "1",
                    "legendShadow": "0",
                    "legendPosition": "right",
                    "legendBorderAlpha": "0",
                    "defaultCenterLabel": "",
                    "centerLabel": "",
                    "centerLabelBold": "0",
                    "showTooltip": "1",
                    "decimals": "0",
                    "captionFontSize": "14",
                    "subcaptionFontSize": "14",
                    "subcaptionFontBold": "0",
                    "useDataPlotColorForLabels": "1",
                    "legendlabel": "ddd"
                },
                "data": undefined
            }
            $scope.options = circularChartOptions;
            dataService.getData($scope.graphDataUrl).then(function(response) {
                var data = response.data;
                var graphFormatedData_1 = circularGraphWithoutCaption(($scope.direction == 'left') ? data.Circular_Graph_left : data.Circular_Graph_right);
                $scope.options.chart.caption = $scope.caption;
                $scope.options.data = graphFormatedData_1;

            });

            function circularGraphWithoutCaption(response) {
                var circulargraphData = response;
                var graphFormatedData = [];
                var colors = $scope.colorsArray;
                for (var i = 0; i < circulargraphData.length; i++) {
                    var obj = circulargraphData[i];
                    graphFormatedData.push({
                        "label": obj.label,
                        "value": obj.count,
                        "color": colors[i % colors.length]
                    })
                }
                return graphFormatedData;
            }


        }
    }
})


chartsApp.filter('makeArray',function(){
	return function(obj){
		var arr=[];
		for(key in obj){
			if(key!='$$hashKey')
			arr.push(obj[key]);
		}
		return arr;
	}
})
chartsApp.directive('chartTable', function() {
    return {
        restrict: "EA",
        scope: {
            tableTitle: '@',
            tableDataUrl: '=',
            tableId: '@'
        },
        template: '<label class="tableTitle">{{tableTitle}}</label>' +
            '<table class="table table-striped" cellspacing="0" width="100%">' +
            '<tbody>' +
            '<tr clas="border-less" ng-repeat="row in tableData.data.rows">' +
            '<td style="border:none" ng-repeat="item in row|makeArray">{{(!$last)?item:"("+item+")"}}</td>' +
            '</tr>' +
            '</tbody>' +
            '</table>',
        controller: function($scope, dataService) {
            $scope.tableData = {
                data: {
                    rows: []
                }
            };
            dataService.getData($scope.tableDataUrl).then(function(response) {
                $scope.tableData = response.data[$scope.tableId];

            });
        }
    }
})