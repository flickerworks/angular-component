chartsApp.controller('rootCtrl', function($scope, dataService, $timeout) {

    //config variable for pyramid chart 
    $scope.pyCharts = dataService.funnelChartConfig();
    $scope.pyFlag = false;
    $scope.pyramidColors = pyramidGraphColors;
    // config variable for line chart
    $scope.line_flag = false;
    $scope.line_chart = dataService.lineChartConfig();
    //config variable for circular graph
    $scope.left_circular = false;
    $scope.firstChart_2 = dataService.circularGraphObject();
    $scope.firstChart_3 = dataService.circularGraphObject();
    $scope.left_circular = true;
    $scope.rightCircular = true;
    

    $scope.dataurl="../../static/gg/custom_json/a042_jouhou1.json";
    //reload the graph
    $scope.reloadGraph = function() {
        $scope.createGraph();
        $scope.$apply();
    }
    $scope.createGraph = function() {
            dataService.getData(JSON_PAGE_URL).then(dataSuccessFull);

            function dataSuccessFull(response) {
                var allData = response.data; // complete json for the page
                function createPyramidData() {
                    var pyramidData = allData.pyramid1;
                    $scope.pyCharts.chart.caption = pyramidData.meta.title
                    var funnelData = pyramidData.data.categories;
                    var arrData = []
                    for (var index = 0; index < funnelData.length; index++) {
                        var obj = funnelData[index];
                        arrData.push({
                            label: obj.label + '{BR} ' + obj.value,
                            value: obj.value,
                            color: $scope.pyramidColors[index % $scope.pyramidColors.length]
                        });
                    }
                    $scope.pyCharts.data = arrData; //    pyramid chart******************
                    $scope.pyFlag = true;
                }

                function createTopRightTable() {
                    var tableData = response.data.table_small_right1;
                    $scope.columns_1 = tableData.columns;
                    $scope.data_1 = tableData.rows;
                }

                function createLineChart(lineGraphCaption, lineGraphSubcaption) {
                    $scope.line_chart.chart.caption = lineGraphCaption;
                    $scope.line_chart.chart.subcaption = lineGraphSubcaption
                    $scope.line_flag = true;
                    $scope.line_chart.categories[0].category = [];
                    var lineChartXAxis = response.data.line_graph.xaxis.data;
                    lineChartXAxis.forEach(function(item) {
                        $scope.line_chart.categories[0].category.push({
                            "label": item.value,
                            "stepSkipped": false
                        })
                    });
                    $scope.line_chart.chart.caption = response.data.line_graph.meta.title;
                    var line_colors = lineGraphColors;
                    $scope.line_chart.dataset = [];
                    response.data.line_graph.series.forEach(function(item, index) {
                        item.color = line_colors[index % line_colors.length];
                        $scope.line_chart.dataset[index] = item;
                    })
                }

                

                function circularGraphWithoutCaption(response) {
                    var circulargraphData = response;
                    var graphFormatedData = [];
                    var colors = circularGraphColors;
                    for (var i = 0; i < circulargraphData.length; i++) {
                        var obj = circulargraphData[i];
                        graphFormatedData.push({
                            "label": obj.label,
                            "value": obj.count,
                            "color": colors[i % colors.length]
                        })
                    }
                    return graphFormatedData;
                }

                function createLeftCircularGraph(caption) {
                    var graphFormatedData_1 = circularGraphWithoutCaption(response.data.Circular_Graph_left);
                    $scope.firstChart_2.data = graphFormatedData_1;
                    $scope.firstChart_2.chart.caption = caption;
                    $scope.left_circular = true;
                }

                function createRightCircularGraph(chartCaption) {
                    var graphFormatedData_2 = circularGraphWithoutCaption(response.data.Circular_Graph_right);
                    $scope.firstChart_3.data = graphFormatedData_2;
                    $scope.firstChart_3.chart.caption = chartCaption;
                    $scope.rightCircular = true;
                }
                createPyramidData();
                createTopRightTable();
                createLineChart(LINE_CAPTION, LINE_SUBCAPTION);
            }
        }
         $scope.createGraph();
})