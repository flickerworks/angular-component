var chartsApp = angular.module("chartsApp", ['ng-fusioncharts', 'ui.grid']);
var JSON_PAGE_URL = "../../static/gg/custom_json/a042_jouhou1.json";
//-------------line graph caption-------------------------------------------------------
var lineGraphColors = ["#C72C5E", "#DE3E58", "#A1B1C3"]
var LINE_CAPTION = "caption for line graph";
var LINE_SUBCAPTION = "subcaption for line graph"
var lineChartOptions = {
        "chart": {
            "caption": "Daily Visits",
            "linethickness": "1",
            "showvalues": "0",
            "formatnumberscale": "0",
            "anchorradius": "2",
            "divlinecolor": "666666",
            "divlinealpha": "30",
            "divlineisdashed": "1",
            "labelstep": "2",
            "bgcolor": "FFFFFF",
            "showalternatehgridcolor": "0",
            "labelpadding": "10",
            "canvasborderthickness": "1",
            "legendiconscale": "1.5",
            "legendshadow": "0",
            "legendborderalpha": "0",
            "canvasborderalpha": "50",
            "numvdivlines": "5",
            "vdivlinealpha": "20",
            "showborder": "0"
        },
        "categories": [{
            "category": []
        }],
        "dataset": []
    }
    //____________________-lineChartOptions____________________
var CIRCULAR_GRAPH1_CAPTION = "circular_graph1";
var LEFT_CIRCULAR_GRAPH = "circular_graph1"
var circularGraphColors = ["#CD0A59", "#E84F63", "#D3D3D3"];


//____________________-pyramidChartOptions____________________
var pyramidGraphColors = ["#9BAEBC", "# E65065", "#CB145B"];
var pyramidChartOptions = {
    "chart": {
        "caption": "",
        "subcaption": "",
        "linethickness": "1",
        "showvalues": "0",
        "formatnumberscale": "0",
        "anchorradius": "2",
        "divlinecolor": "666666",
        "divlinealpha": "30",
        "divlineisdashed": "1",
        "labelstep": "2",
        "bgcolor": "FFFFFF",
        "showalternatehgridcolor": "0",
        "labelpadding": "10",
        "canvasborderthickness": "1",
        "legendiconscale": "1.5",
        "legendshadow": "0",
        "legendborderalpha": "0",
        "canvasborderalpha": "50",
        "numvdivlines": "5",
        "vdivlinealpha": "20",
        "showborder": "0",
        "showtooltip": "1",
        "paletteColors": "#46b8da,#993f6c,#cc0000",
        labelDisplay: "wrap",
        "showLabelsAtCenter": "1",
        "baseFontSize": "12",
        "baseFontColor": "#fff",
        "numberSuffix": "$",
        "plotToolText": "$label",
        "showToolTipShadow": "1",
        "toolTipBorderColor": "#FFFFFF",
        "plottooltext": "<div class='tooltip-custom'>$label</div>",
        "showLegend": "1",
        "outCnvBaseFontColor": "#8D8D8D",
    },
    "data": [],
    "styles": {
        "definition": [{
            "name": "myToolTipFont",
            "type": "font",
            "font": "Arial",
            "size": "12",
            "color": "FF5904"
        }],
        "application": [{
            "toobject": "ToolTip",
            "styles": "myToolTipFont"
        }]
    }
}



//___________________________ circular chart options-------------------------------------
//var CIRCULAR_GRAPH1_CAPTION = "circular_graph1";
//var LEFT_CIRCULAR_GRAPH = "circular_graph1"
//var circularGraphColors = ["#CD0A59", "#E84F63", "#D3D3D3"];
var circularChartOptions = {
    "chart": {
        "enableSmartLabels": "1",
        "chartTopMargin": "0",
        "chartRightMargin": "0",
        "chartBottomMargin": "0",
        "caption": "",
        "subCaption": "",
        "numberPrefix": "",
        "bgColor": "#ffffff",
        "showBorder": "0",
        "use3DLighting": "0",
        "showShadow": "0",
        "enableSmartLabels": "0",
        "startingAngle": "310",
        "showLabels": "0",
        "showValues": "1",
        "showPercentValues": "1",
        "showLegend": "1",
        "legendShadow": "0",
        "legendPosition": "right",
        "legendBorderAlpha": "0",
        "defaultCenterLabel": "",
        "centerLabel": "",
        "centerLabelBold": "0",
        "showTooltip": "1",
        "decimals": "0",
        "captionFontSize": "14",
        "subcaptionFontSize": "14",
        "subcaptionFontBold": "0",
        "useDataPlotColorForLabels": "1",
        "legendlabel": "ddd"
    },
    "data": undefined
}



//---------------------table 2 options--------------------------------------------
var table2options = {
    fitColumns: true,
    columns: [{
        title: "brand",
        field: "name"
    }, {
        title: "percentage",
        field: "pct",
        align: "center",
        formatter: "progress"
    }, {
        title: "percentage",
        field: "pct",
        align: "center",
        formatter: pctFormat
    }, {
        title: "count",
        field: "count"
    }, {
        title: "nb",
        field: "count"
    }],
}

function pctFormat(value, data, cell, row, options) {
    return value + "%";
}; //plain text value
//------------------big table options----
var bigTableOptions = {
    fitColumns: true,
    columns: [{
        title: "id",
        field: "id",
        align: "right",
        sorter: "number"
    }, {
        title: "brand",
        field: "name"
    }, {
        title: "percentage",
        field: "pct",
        align: "center",
        formatter: "progress"
    }, {
        title: "percentage",
        field: "pct",
        align: "center",
        formatter: pctFormat
    }, {
        title: "count",
        field: "count"
    }, {
        title: "nb",
        field: "count"
    }],
}